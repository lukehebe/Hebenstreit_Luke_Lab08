import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class TagExtractorGUI extends JFrame implements ActionListener {
    private static final long serialVersionUID = 1L;
    private JTextArea textArea;
    private JButton chooseFileButton, chooseStopWordButton, extractButton, saveButton;
    private File selectedFile, stopWordsFile;
    private Map<String, Integer> tagFrequencyMap;

    public TagExtractorGUI() {
        super("Tag Extractor");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        
        textArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(textArea);

        chooseFileButton = new JButton("Choose File");
        chooseFileButton.addActionListener(this);

        chooseStopWordButton = new JButton("Choose Stop Word File");
        chooseStopWordButton.addActionListener(this);

        extractButton = new JButton("Extract Tags");
        extractButton.addActionListener(this);

        saveButton = new JButton("Save Tags");
        saveButton.addActionListener(this);